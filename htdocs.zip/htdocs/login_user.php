<?php
session_start();
include 'config.php';

if (isset($_POST['login'])) {
    $user = mysqli_real_escape_string($conn, $_POST['user']);
    $pass = $_POST['pass'];

    $result = mysqli_query($conn, "SELECT * FROM users WHERE username='$user'");
    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if (password_verify($pass, $row['password'])) {
            $_SESSION['user'] = $row['username'];
            $_SESSION['user_id'] = $row['id'];
            header("Location: index.php");
            exit();
        }
    }
    $error = "Username atau Password salah!";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Member - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#050b18] text-white flex items-center justify-center h-screen px-6">
    <div class="w-full max-w-sm p-8 bg-slate-900 rounded-2xl border border-cyan-500/30 shadow-2xl">
        <h2 class="text-2xl font-bold text-center text-cyan-400 mb-6">LOGIN MEMBER</h2>
        <?php if(isset($error)) echo "<p class='text-red-500 text-xs mb-4 text-center'>$error</p>"; ?>
        <form method="POST" class="space-y-4">
            <input type="text" name="user" placeholder="Username" class="w-full p-4 bg-slate-800 rounded-xl border border-slate-700 outline-none focus:border-cyan-500" required>
            <input type="password" name="pass" placeholder="Password" class="w-full p-4 bg-slate-800 rounded-xl border border-slate-700 outline-none focus:border-cyan-500" required>
            <button type="submit" name="login" class="w-full bg-cyan-600 py-4 rounded-xl font-bold active:scale-95 transition">MASUK</button>
        </form>
        <p class="text-center text-xs mt-6 text-slate-500">Belum punya akun? <a href="register.php" class="text-cyan-400 font-bold">Daftar</a></p>
    </div>
</body>
</html>