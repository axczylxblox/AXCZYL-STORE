<?php
session_start();
include 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: login_user.php"); exit(); }

$uid = $_SESSION['user_id'];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM users WHERE id='$uid'"));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#050b18] text-white p-6">
    <h2 class="text-xl font-bold mb-8 text-cyan-400">AKUN SAYA</h2>
    
    <div class="bg-slate-900 p-6 rounded-2xl border border-slate-800 mb-6">
        <div class="flex items-center gap-4 mb-6">
            <div class="w-16 h-16 bg-cyan-600/20 rounded-full flex items-center justify-center border border-cyan-500">
                <i class="fa-solid fa-user text-2xl text-cyan-400"></i>
            </div>
            <div>
                <p class="font-bold text-lg"><?php echo $user['username']; ?></p>
                <p class="text-xs text-slate-500 uppercase italic">Member Level: Basic</p>
            </div>
        </div>
        
        <div class="border-t border-slate-800 pt-4 flex justify-between items-center">
            <span class="text-sm text-slate-400 font-bold uppercase">Saldo Utama</span>
            <span class="text-green-400 font-bold">Rp <?php echo number_format($user['balance']); ?></span>
        </div>
    </div>

    <div class="space-y-3">
        <a href="riwayat.php" class="block w-full p-4 bg-slate-900 rounded-xl text-sm font-bold border border-slate-800">Riwayat Transaksi</a>
        <a href="deposit.php" class="block w-full p-4 bg-slate-900 rounded-xl text-sm font-bold border border-slate-800">Isi Saldo / Topup</a>
        <a href="logout.php" class="block w-full p-4 bg-red-600/10 rounded-xl text-sm font-bold border border-red-600/30 text-red-500 text-center">KELUAR / LOGOUT</a>
    </div>

    <a href="index.php" class="block text-center text-xs text-slate-500 mt-10 uppercase tracking-widest font-bold">Kembali ke Home</a>
</body>
</html>