<?php
// Aktifkan laporan error untuk memudahkan pelacakan
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'config.php';

// Pastikan user sudah login sebelum deposit
if (!isset($_SESSION['user_id'])) {
    die("Akses Ditolak: Silakan login terlebih dahulu.");
}

if (isset($_POST['submit_depo'])) {
    // Ambil data dari session dan form
    $user_id  = $_SESSION['user_id'];
    $username = $_SESSION['user'];
    $jumlah   = mysqli_real_escape_string($conn, $_POST['jumlah']);
    $metode   = mysqli_real_escape_string($conn, $_POST['metode']);
    
    // Proses Upload Bukti Transaksi
    $nama_file   = $_FILES['bukti']['name'];
    $ukuran_file = $_FILES['bukti']['size'];
    $tmp_file    = $_FILES['bukti']['tmp_name'];
    $ekstensi    = strtolower(pathinfo($nama_file, PATHINFO_EXTENSION));
    
    // Validasi ekstensi file (hanya gambar)
    $allowed_ext = array('jpg', 'jpeg', 'png');
    if (!in_array($ekstensi, $allowed_ext)) {
        die("Error: Format file harus JPG, JPEG, atau PNG.");
    }

    // Buat nama file unik: DEPO_username_timestamp.ext
    $nama_baru = "DEPO_" . $username . "_" . time() . "." . $ekstensi;
    $folder    = "uploads/";

    // Buat folder jika belum ada
    if (!is_dir($folder)) { 
        mkdir($folder, 0777, true); 
    }

    // Pindahkan file ke folder uploads
    if (move_uploaded_file($tmp_file, $folder . $nama_baru)) {
        
        // Simpan data ke tabel 'deposits'
        // Pastikan nama kolom sesuai dengan SQL: id, user_id, username, amount, method, proof_file, status, created_at
        $sql = "INSERT INTO deposits (user_id, username, amount, method, proof_file, status) 
                VALUES ('$user_id', '$username', '$jumlah', '$metode', '$nama_baru', 'pending')";
        
        if (mysqli_query($conn, $sql)) {
            echo "<script>
                    alert('Deposit Berhasil Dikirim! Silakan tunggu konfirmasi admin.');
                    window.location='riwayat.php';
                  </script>";
        } else {
            // Jika query gagal, tampilkan error SQL
            die("Gagal simpan ke database: " . mysqli_error($conn));
        }

    } else {
        // Jika upload file gagal (biasanya karena folder uploads tidak ada atau tidak ada izin tulis)
        die("Gagal upload file ke server. Pastikan folder 'uploads' sudah ada dan memiliki izin akses 777.");
    }
} else {
    // Jika file diakses langsung tanpa submit form
    header("Location: deposit.php");
    exit();
}
?>