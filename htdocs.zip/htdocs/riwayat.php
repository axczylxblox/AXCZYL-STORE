<?php
session_start();
include 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$uid = $_SESSION['user_id'];
$history = mysqli_query($conn, "SELECT * FROM transactions WHERE user_id='$uid' ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RIWAYAT - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #020617; color: white; }
        .glass { background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(255, 255, 255, 0.1); }
        .struk { background: #fff; color: #000; font-family: 'Courier New', monospace; box-shadow: 0 0 50px rgba(0,0,0,0.5); }
    </style>
</head>
<body class="p-6">
    <div class="flex items-center gap-4 mb-8">
        <a href="index.php" class="text-slate-500"><i class="fa-solid fa-chevron-left"></i></a>
        <h2 class="text-xl font-bold italic text-red-500 uppercase">RIWAYAT ANDA</h2>
    </div>

    <div class="space-y-4">
        <?php if(mysqli_num_rows($history) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($history)): ?>
            <div class="glass p-5 rounded-3xl flex justify-between items-center border-l-4 <?php echo ($row['status'] == 'success') ? 'border-green-500' : 'border-red-500'; ?>">
                <div>
                    <p class="font-black text-sm"><?php echo $row['service_name']; ?></p>
                    <p class="text-[10px] text-slate-500"><?php echo $row['target_number']; ?></p>
                    <span class="text-[9px] uppercase font-bold <?php echo ($row['status'] == 'success') ? 'text-green-500' : 'text-yellow-500'; ?>">
                        ● <?php echo $row['status']; ?>
                    </span>
                </div>
                <button onclick="bukaStruk('<?php echo $row['service_name']; ?>', '<?php echo $row['target_number']; ?>', '<?php echo number_format($row['amount']); ?>', '<?php echo $row['status']; ?>')" 
                        class="bg-white/5 px-4 py-2 rounded-xl text-[10px] font-bold border border-white/10 uppercase italic">
                    Struk
                </button>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p class="text-center opacity-30 py-10 italic">Belum ada transaksi.</p>
        <?php endif; ?>
    </div>

    <div id="modalStruk" class="fixed inset-0 bg-black/90 hidden items-center justify-center p-6 z-[999]">
        <div class="struk p-8 w-full max-w-sm rounded-lg relative">
            <div class="text-center border-b-2 border-dashed border-black pb-4 mb-4">
                <h3 class="font-black text-xl italic">AXCZYL STORE</h3>
                <p class="text-[9px] font-bold uppercase tracking-widest">Digital Receipt - Official</p>
            </div>
            
            <div class="space-y-3 text-xs">
                <div class="flex justify-between"><span>ITEM:</span> <span id="s_produk" class="font-bold"></span></div>
                <div class="flex justify-between"><span>TARGET:</span> <span id="s_target" class="font-bold"></span></div>
                <div class="flex justify-between border-t border-black pt-2 font-black text-sm">
                    <span>TOTAL:</span> <span id="s_harga"></span>
                </div>
                <div class="flex justify-between"><span>STATUS:</span> <span id="s_status" class="font-bold italic uppercase text-green-700"></span></div>
            </div>

            <div class="mt-6 pt-4 border-t-2 border-dashed border-black text-[9px] text-center italic">
                Simpan struk ini sebagai bukti sah.<br>Terima kasih telah berlangganan!
            </div>

            <button onclick="tutupStruk()" class="mt-6 w-full bg-black text-white py-3 rounded-md font-bold text-xs uppercase tracking-tighter active:scale-95 transition">Tutup Struk</button>
        </div>
    </div>

    <script>
        function bukaStruk(p, t, h, s) {
            document.getElementById('s_produk').innerText = p;
            document.getElementById('s_target').innerText = t;
            document.getElementById('s_harga').innerText = "Rp " + h;
            document.getElementById('s_status').innerText = s;
            
            const modal = document.getElementById('modalStruk');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function tutupStruk() {
            const modal = document.getElementById('modalStruk');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
    </script>
</body>
</html>