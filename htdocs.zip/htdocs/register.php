<?php
include 'config.php';
if (isset($_POST['register'])) {
    $user = mysqli_real_escape_string($conn, $_POST['user']);
    $pass = password_hash($_POST['pass'], PASSWORD_DEFAULT); // Password dienkripsi biar aman

    $check = mysqli_query($conn, "SELECT * FROM users WHERE username='$user'");
    if (mysqli_num_rows($check) > 0) {
        $error = "Username sudah terpakai!";
    } else {
        $query = "INSERT INTO users (username, password, role, balance) VALUES ('$user', '$pass', 'member', 0)";
        if (mysqli_query($conn, $query)) {
            header("Location: login_user.php?msg=Berhasil Daftar, Silakan Login");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#050b18] text-white flex items-center justify-center h-screen px-6 font-sans">
    <div class="w-full max-w-sm p-8 bg-slate-900 rounded-2xl border border-cyan-500/30">
        <h2 class="text-2xl font-bold text-center mb-2 text-cyan-400">DAFTAR AKUN</h2>
        <p class="text-[10px] text-center text-slate-500 mb-6 uppercase tracking-widest">Join Axczyl Digital Ecosystem</p>
        
        <?php if(isset($error)) echo "<p class='text-red-500 text-xs mb-4 text-center'>$error</p>"; ?>

        <form method="POST" class="space-y-4">
            <input type="text" name="user" placeholder="Username" class="w-full p-4 bg-slate-800 rounded-xl border border-slate-700 focus:border-cyan-500 outline-none" required>
            <input type="password" name="pass" placeholder="Password" class="w-full p-4 bg-slate-800 rounded-xl border border-slate-700 focus:border-cyan-500 outline-none" required>
            <button type="submit" name="register" class="w-full bg-cyan-600 py-4 rounded-xl font-bold shadow-lg shadow-cyan-900/20 active:scale-95 transition">DAFTAR SEKARANG</button>
        </form>
        <p class="text-center text-xs mt-6 text-slate-500">Sudah punya akun? <a href="login_user.php" class="text-cyan-400 font-bold">Login</a></p>
    </div>
</body>
</html>