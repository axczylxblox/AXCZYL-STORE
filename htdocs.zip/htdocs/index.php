<?php 
session_start(); 
include 'config.php';

$balance = 0;
$username = "Guest";
if (isset($_SESSION['user_id'])) {
    $uid = $_SESSION['user_id'];
    $user_query = mysqli_query($conn, "SELECT * FROM users WHERE id='$uid'");
    $u_data = mysqli_fetch_assoc($user_query);
    $balance = $u_data['balance'];
    $username = $u_data['username'];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AXCZYL PPOB - Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #050b18; color: white; font-family: sans-serif; }
        .neon-text { text-shadow: 0 0 8px #00f2ff; color: #00f2ff; }
        .glass { background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); }
        .active-scale:active { transform: scale(0.95); transition: 0.1s; }
        .modal-bg { background: rgba(0, 0, 0, 0.8); backdrop-filter: blur(5px); }
    </style>
</head>
<body class="pb-24">

    <div class="p-6 flex justify-between items-center">
        <div>
            <h1 class="text-xl font-bold tracking-tighter neon-text uppercase">AXCZYL STORE</h1>
            <p class="text-[10px] text-slate-500 uppercase font-mono">User: <span class="text-white"><?php echo $username; ?></span></p>
        </div>
        <div class="text-right">
            <p class="text-[10px] text-slate-500 font-bold uppercase">Saldo Lu:</p>
            <p class="font-bold text-green-400 text-lg">Rp <?php echo number_format($balance); ?></p>
        </div>
    </div>

    <div class="px-6 mb-8">
        <div class="h-32 w-full rounded-2xl glass flex flex-col items-center justify-center border border-cyan-500/20 relative overflow-hidden text-center p-4">
            <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 to-blue-600"></div>
            <p class="text-cyan-400 font-mono text-xs animate-pulse font-black uppercase">SYSTEM NORMAL</p>
            <p class="text-[10px] text-slate-400 mt-2 italic font-medium">Layanan Topup Otomatis & Terpercaya <br> Beroperasi 24 Jam Non-Stop <br> Tanpa Biaya Admin 100%</p>
        </div>
    </div>

    <div class="px-6 grid grid-cols-4 gap-y-8 gap-x-4 text-center">
        <button onclick="toggleModal('modal-ewallet')" class="flex flex-col items-center active-scale outline-none">
            <div class="w-14 h-14 glass rounded-2xl flex items-center justify-center mb-2 border border-slate-800 shadow-lg group hover:border-cyan-500 transition">
                <i class="fa-solid fa-wallet text-cyan-400 text-xl"></i>
            </div>
            <span class="text-[10px] font-medium text-slate-300 uppercase italic">E-Wallet</span>
        </button>

        <button onclick="toggleModal('modal-bank')" class="flex flex-col items-center active-scale outline-none">
            <div class="w-14 h-14 glass rounded-2xl flex items-center justify-center mb-2 border border-slate-800 shadow-lg hover:border-blue-500 transition">
                <i class="fa-solid fa-building-columns text-blue-400 text-xl"></i>
            </div>
            <span class="text-[10px] font-medium text-slate-300 uppercase italic">Bank</span>
        </button>

        <a href="layanan.php?cat=Tools" class="flex flex-col items-center active-scale">
            <div class="w-14 h-14 glass rounded-2xl flex items-center justify-center mb-2 border border-slate-800 shadow-lg"><i class="fa-solid fa-gamepad text-cyan-400 text-xl"></i></div>
            <span class="text-[10px] font-medium text-slate-300 uppercase italic">Tools</span>
        </a>
        <a href="layanan.php?cat=pulsa" class="flex flex-col items-center active-scale">
            <div class="w-14 h-14 glass rounded-2xl flex items-center justify-center mb-2 border border-slate-800 shadow-lg"><i class="fa-solid fa-mobile-screen text-cyan-400 text-xl"></i></div>
            <span class="text-[10px] font-medium text-slate-300 uppercase italic">Pulsa</span>
        </a>
        <a href="layanan.php?cat=internet" class="flex flex-col items-center active-scale">
            <div class="w-14 h-14 glass rounded-2xl flex items-center justify-center mb-2 border border-slate-800 shadow-lg"><i class="fa-solid fa-wifi text-cyan-400 text-xl"></i></div>
            <span class="text-[10px] font-medium text-slate-300 uppercase italic">Kuota</span>
        </a>
        <a href="layanan.php?cat=token" class="flex flex-col items-center active-scale">
            <div class="w-14 h-14 glass rounded-2xl flex items-center justify-center mb-2 border border-slate-800 shadow-lg"><i class="fa-solid fa-bolt text-cyan-400 text-xl"></i></div>
            <span class="text-[10px] font-medium text-slate-300 uppercase italic">Token</span>
        </a>

        <div onclick="alert('Coming Soon, Master!')" class="flex flex-col items-center opacity-40">
            <div class="w-14 h-14 glass rounded-2xl flex items-center justify-center mb-2 border border-slate-800 shadow-lg"><i class="fa-solid fa-users text-slate-500 text-xl"></i></div>
            <span class="text-[9px] font-medium text-slate-500 uppercase">SMM</span>
        </div>
        <div onclick="alert('Coming Soon, Master!')" class="flex flex-col items-center opacity-40">
            <div class="w-14 h-14 glass rounded-2xl flex items-center justify-center mb-2 border border-slate-800 shadow-lg"><i class="fa-brands fa-whatsapp text-slate-500 text-xl"></i></div>
            <span class="text-[9px] font-medium text-slate-500 uppercase italic">WA OTP</span>
        </div>
    </div>

    <div class="mx-6 mt-12 p-5 rounded-2xl glass border border-green-500/20 shadow-xl flex justify-between items-center">
        <div>
            <h3 class="text-xs font-bold text-slate-300 uppercase mb-1">SALDO KURANG?</h3>
            <p class="text-[9px] text-slate-500 italic">Topup Tanpa Biaya Admin</p>
        </div>
        <a href="deposit.php" class="bg-green-600 px-6 py-2 rounded-full text-[10px] font-bold uppercase shadow-lg shadow-green-900/20 active-scale transition hover:bg-green-500">Deposit Sekarang</a>
    </div>

    <div id="modal-ewallet" class="fixed inset-0 z-[100] modal-bg hidden flex items-center justify-center p-6">
        <div class="w-full glass rounded-3xl p-6 border border-cyan-500/30">
            <div class="flex justify-between items-center mb-6">
                <h3 class="font-black italic text-cyan-400 uppercase tracking-tighter">E-Wallet Menu</h3>
                <button onclick="toggleModal('modal-ewallet')"><i class="fa-solid fa-xmark text-slate-500"></i></button>
            </div>
            <div class="grid grid-cols-1 gap-3">
                <a href="layanan.php?cat=dana" class="p-4 glass rounded-xl flex items-center gap-3 border border-white/5 active-scale font-bold italic text-sm"><i class="fa-solid fa-circle-check text-cyan-500 text-xs"></i> DANA</a>
                <a href="layanan.php?cat=gopay" class="p-4 glass rounded-xl flex items-center gap-3 border border-white/5 active-scale font-bold italic text-sm"><i class="fa-solid fa-circle-check text-cyan-500 text-xs"></i> GOPAY</a>
                <a href="layanan.php?cat=seabank" class="p-4 glass rounded-xl flex items-center gap-3 border border-white/5 active-scale font-bold italic text-sm"><i class="fa-solid fa-circle-check text-cyan-500 text-xs"></i> SEABANK</a>
                <a href="layanan.php?cat=shopeepay" class="p-4 glass rounded-xl flex items-center gap-3 border border-white/5 active-scale font-bold italic text-sm"><i class="fa-solid fa-circle-check text-cyan-500 text-xs"></i> SHOPEEPAY</a>
                <a href="layanan.php?cat=ovo" class="p-4 glass rounded-xl flex items-center gap-3 border border-white/5 active-scale font-bold italic text-sm"><i class="fa-solid fa-circle-check text-cyan-500 text-xs"></i> OVO</a>
            </div>
        </div>
    </div>

    <div id="modal-bank" class="fixed inset-0 z-[100] modal-bg hidden flex items-center justify-center p-6">
        <div class="w-full glass rounded-3xl p-6 border border-blue-500/30">
            <div class="flex justify-between items-center mb-6">
                <h3 class="font-black italic text-blue-400 uppercase tracking-tighter">Bank Menu</h3>
                <button onclick="toggleModal('modal-bank')"><i class="fa-solid fa-xmark text-slate-500"></i></button>
            </div>
            <div class="grid grid-cols-1 gap-3">
                <a href="layanan.php?cat=bca" class="p-4 glass rounded-xl flex items-center gap-3 border border-white/5 active-scale font-bold italic text-sm"><i class="fa-solid fa-circle-check text-blue-500 text-xs"></i> BANK BCA</a>
                <a href="layanan.php?cat=bri" class="p-4 glass rounded-xl flex items-center gap-3 border border-white/5 active-scale font-bold italic text-sm"><i class="fa-solid fa-circle-check text-blue-500 text-xs"></i> BANK BRI</a>
            </div>
        </div>
    </div>

    <div class="fixed bottom-0 left-0 right-0 h-16 bg-[#0f172a]/90 backdrop-blur-md border-t border-slate-800 flex justify-around items-center z-50">
        <a href="index.php" class="flex flex-col items-center text-cyan-400">
            <i class="fa-solid fa-house text-lg"></i>
            <span class="text-[9px] mt-1 font-bold">Home</span>
        </a>
        <a href="riwayat.php" class="flex flex-col items-center text-slate-500 hover:text-cyan-400 transition">
            <i class="fa-solid fa-receipt text-lg"></i>
            <span class="text-[9px] mt-1 font-bold">History</span>
        </a>
        <a href="https://wa.me/6289517604572" class="flex flex-col items-center text-slate-500">
            <i class="fa-solid fa-headset text-lg"></i>
            <span class="text-[9px] mt-1 font-bold">Support</span>
        </a>
        <a href="<?php echo isset($_SESSION['user_id']) ? 'profil.php' : 'login_user.php'; ?>" class="flex flex-col items-center text-slate-500">
            <i class="fa-solid fa-user text-lg <?php echo isset($_SESSION['user_id']) ? 'text-green-500' : ''; ?>"></i>
            <span class="text-[9px] mt-1 font-bold"><?php echo isset($_SESSION['user_id']) ? 'Account' : 'Login'; ?></span>
        </a>
    </div>

    <script>
        function toggleModal(id) {
            const modal = document.getElementById(id);
            if (modal.classList.contains('hidden')) {
                modal.classList.remove('hidden');
            } else {
                modal.classList.add('hidden');
            }
        }
        
        // Klik di luar modal buat nutup
        window.onclick = function(event) {
            if (event.target.classList.contains('modal-bg')) {
                event.target.classList.add('hidden');
            }
        }
    </script>

</body>
</html>