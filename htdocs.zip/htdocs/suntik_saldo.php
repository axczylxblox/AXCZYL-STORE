<?php
session_start();
include 'config.php';
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }

if (isset($_POST['suntik'])) {
    $target_user = $_POST['username'];
    $jumlah = $_POST['jumlah'];
    
    // Cek apakah user ada
    $check = mysqli_query($conn, "SELECT * FROM users WHERE username='$target_user'");
    if (mysqli_num_rows($check) > 0) {
        mysqli_query($conn, "UPDATE users SET balance = balance + $jumlah WHERE username='$target_user'");
        $success = "Saldo berhasil disuntik ke $target_user!";
    } else {
        $error = "Username tidak ditemukan!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Suntik Saldo - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-white p-6">
    <div class="flex items-center gap-4 mb-8">
        <a href="admin_panel.php" class="text-slate-500"><i class="fa-solid fa-arrow-left text-xl"></i></a>
        <h2 class="text-xl font-bold italic text-green-500 uppercase">SUNTIK SALDO</h2>
    </div>

    <?php if(isset($success)) echo "<div class='p-4 bg-green-600/20 text-green-400 rounded-xl mb-4'>$success</div>"; ?>
    <?php if(isset($error)) echo "<div class='p-4 bg-red-600/20 text-red-400 rounded-xl mb-4'>$error</div>"; ?>

    <form method="POST" class="space-y-6">
        <div>
            <label class="text-[10px] text-slate-500 uppercase font-bold ml-1">Username Target</label>
            <input type="text" name="username" placeholder="Contoh: user_keren" class="w-full p-4 bg-slate-900 rounded-2xl border border-slate-800 outline-none focus:border-green-500" required>
        </div>
        <div>
            <label class="text-[10px] text-slate-500 uppercase font-bold ml-1">Jumlah Saldo (Rp)</label>
            <input type="number" name="jumlah" placeholder="Contoh: 100000" class="w-full p-4 bg-slate-900 rounded-2xl border border-slate-800 outline-none focus:border-green-500" required>
        </div>
        <button type="submit" name="suntik" class="w-full bg-green-600 py-4 rounded-2xl font-bold uppercase shadow-lg shadow-green-900/20">Eksekusi Suntik Saldo</button>
    </form>
</body>
</html>