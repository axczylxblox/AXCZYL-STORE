<?php
session_start();
include 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: login_user.php"); exit(); }
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEPOSIT SALDO - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #050b18; color: white; font-family: 'Inter', sans-serif; }
        .glass { background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); }
        .neon-text { text-shadow: 0 0 10px rgba(6, 182, 212, 0.5); }
        .hidden { display: none; }
    </style>
</head>
<body class="p-6 pb-20">

    <div class="flex items-center gap-4 mb-8">
        <a href="index.php" class="w-10 h-10 bg-slate-900 rounded-full flex items-center justify-center border border-slate-800"><i class="fa-solid fa-arrow-left"></i></a>
        <h2 class="text-xl font-bold uppercase tracking-widest text-cyan-400 italic neon-text">DEPOSIT SALDO</h2>
    </div>

    <div id="step1" class="space-y-6">
        <div class="space-y-2">
            <label class="text-[10px] font-bold text-slate-500 uppercase ml-1 tracking-widest">JUMLAH (Rp)</label>
            <div class="relative">
                <span class="absolute left-4 top-4 text-cyan-500 font-bold italic">Rp</span>
                <input type="number" id="input_jumlah" placeholder="Contoh: 20000" class="w-full p-4 pl-12 bg-slate-900 rounded-2xl border border-slate-800 font-bold text-lg outline-none focus:border-cyan-500">
            </div>
        </div>

        <div class="space-y-2">
            <label class="text-[10px] font-bold text-slate-500 uppercase ml-1 tracking-widest">METODE PEMBAYARAN</label>
            <select id="input_metode" class="w-full p-4 bg-slate-900 rounded-2xl border border-slate-800 font-bold text-sm appearance-none outline-none focus:border-cyan-500">
                <option value="QRIS">QRIS (OTOMATIS)</option>
                <option value="DANA">DANA (MANUAL)</option>
                <option value="GOPAY">GOPAY (MANUAL)</option>
            </select>
        </div>

        <button onclick="nextStep()" class="w-full bg-cyan-600 py-4 rounded-2xl font-bold uppercase shadow-lg shadow-cyan-900/40 transition active:scale-95">LANJUTKAN</button>
    </div>

    <form action="proses_deposit.php" method="POST" enctype="multipart/form-data" id="step2" class="hidden space-y-6">
        <input type="hidden" name="jumlah" id="final_jumlah">
        <input type="hidden" name="metode" id="final_metode">

        <div class="p-6 glass rounded-3xl border border-cyan-500/20">
            <div class="text-center mb-6">
                <p class="text-[10px] text-slate-500 uppercase tracking-widest mb-1">JUMLAH TRANSFER:</p>
                <p id="display_jumlah" class="text-3xl font-black text-white"></p>
            </div>

            <div class="space-y-4">
                <div class="text-center">
                    <p class="text-[10px] text-slate-500 uppercase tracking-widest mb-2">TUJUAN PEMBAYARAN:</p>
                    
                    <div id="target_qris" class="hidden">
                        <img src="https://i.ibb.co.com/pB6ZX1sd/Kode-QRIS-AXCZYL-STORE-Kesehatan-Olahraga.jpg" class="mx-auto rounded-xl border-4 border-white w-48 mb-2">
                        <p class="text-xs font-bold text-cyan-400">SCAN QRIS AXCZYL STORE</p>
                    </div>

                    <div id="target_dana" class="hidden bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
                        <p class="text-xl font-black text-blue-400 tracking-wider">089508349104</p>
                        <p class="text-[10px] text-slate-400">A/N AXCZYL STORE</p>
                    </div>

                    <div id="target_gopay" class="hidden bg-slate-800/50 p-4 rounded-2xl border border-slate-700">
                        <p class="text-xl font-black text-green-400 tracking-wider">089677040178</p>
                        <p class="text-[10px] text-slate-400">A/N AXCZYL STORE</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="space-y-2">
            <label class="text-[10px] font-bold text-slate-500 uppercase ml-1 tracking-widest">UPLOAD BUKTI TRANSFER</label>
            <div class="relative w-full h-14 bg-slate-900 rounded-2xl border border-slate-800 flex items-center px-4 overflow-hidden">
                <i class="fa-solid fa-cloud-arrow-up text-cyan-500 mr-3"></i>
                <input type="file" name="bukti" class="text-xs text-slate-400 file:hidden" required>
            </div>
        </div>

        <div class="flex gap-3">
            <button type="button" onclick="prevStep()" class="flex-1 bg-slate-800 py-4 rounded-2xl font-bold uppercase text-xs border border-slate-700">KEMBALI</button>
            <button type="submit" name="submit_depo" class="flex-[2] bg-cyan-600 py-4 rounded-2xl font-bold uppercase shadow-lg shadow-cyan-900/40">KONFIRMASI</button>
        </div>
    </form>

    <script>
        function nextStep() {
            const jumlah = document.getElementById('input_jumlah').value;
            const metode = document.getElementById('input_metode').value;

            if (jumlah < 1000) {
                alert('Minimal deposit Rp 1.000');
                return;
            }

            // Set Data ke Step 2
            document.getElementById('final_jumlah').value = jumlah;
            document.getElementById('final_metode').value = metode;
            document.getElementById('display_jumlah').innerText = "Rp " + parseInt(jumlah).toLocaleString();

            // Sembunyikan Tujuan Lain
            document.getElementById('target_qris').classList.add('hidden');
            document.getElementById('target_dana').classList.add('hidden');
            document.getElementById('target_gopay').classList.add('hidden');

            // Tampilkan Tujuan Sesuai Pilihan
            if (metode === 'QRIS') document.getElementById('target_qris').classList.remove('hidden');
            if (metode === 'DANA') document.getElementById('target_dana').classList.remove('hidden');
            if (metode === 'GOPAY') document.getElementById('target_gopay').classList.remove('hidden');

            // Switch View
            document.getElementById('step1').classList.add('hidden');
            document.getElementById('step2').classList.remove('hidden');
        }

        function prevStep() {
            document.getElementById('step1').classList.remove('hidden');
            document.getElementById('step2').classList.add('hidden');
        }
    </script>

</body>
</html>