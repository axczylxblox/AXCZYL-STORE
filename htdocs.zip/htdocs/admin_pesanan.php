<?php
session_start();
include 'config.php';
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }

// Logika buat ACC atau Gagal
if (isset($_GET['id']) && isset($_GET['s'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $status = $_GET['s'];
    
    // Kalau ditolak/gagal, balikin saldo user (opsional, tapi bagus biar aman)
    if ($status == 'failed') {
        $trx = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM transactions WHERE id='$id'"));
        $uid = $trx['user_id'];
        $amt = $trx['amount'];
        mysqli_query($conn, "UPDATE users SET balance = balance + $amt WHERE id='$uid'");
    }

    mysqli_query($conn, "UPDATE transactions SET status='$status' WHERE id='$id'");
    echo "<script>alert('Status Pesanan Diupdate!'); window.location='admin_pesanan.php';</script>";
}

// Ambil data dari tabel TRANSACTIONS
$orders = mysqli_query($conn, "SELECT * FROM transactions ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PESANAN MASUK - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #020617; color: white; }
        .glass { background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(255, 255, 255, 0.1); }
    </style>
</head>
<body class="p-6">
    <div class="flex items-center gap-4 mb-8">
        <a href="admin_panel.php" class="text-slate-500"><i class="fa-solid fa-chevron-left text-xl"></i></a>
        <h2 class="text-xl font-black italic text-cyan-500 uppercase">Pesanan Member</h2>
    </div>

    <div class="space-y-4">
        <?php if(mysqli_num_rows($orders) > 0): ?>
            <?php while($o = mysqli_fetch_assoc($orders)): ?>
            <div class="glass p-5 rounded-3xl border-l-4 border-cyan-500">
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <p class="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Produk</p>
                        <p class="font-black text-white"><?php echo $o['service_name']; ?></p>
                    </div>
                    <div class="text-right">
                        <p class="text-[10px] text-slate-500 uppercase font-bold tracking-widest">User</p>
                        <p class="text-xs font-mono">ID: <?php echo $o['user_id']; ?></p>
                    </div>
                </div>
                
                <div class="bg-slate-950/50 p-4 rounded-2xl mb-4 border border-slate-800">
                    <p class="text-[10px] text-slate-500 uppercase mb-1">Target / ID Game:</p>
                    <p class="text-xl font-black text-cyan-400"><?php echo $o['target_number']; ?></p>
                </div>

                <div class="flex gap-2">
                    <a href="?id=<?php echo $o['id']; ?>&s=success" class="flex-1 bg-green-600 py-3 rounded-xl text-center font-bold text-xs shadow-lg shadow-green-900/20">SELESAI</a>
                    <a href="?id=<?php echo $o['id']; ?>&s=failed" class="flex-1 bg-slate-800 py-3 rounded-xl text-center font-bold text-xs text-red-500 border border-slate-700">BATALKAN</a>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="text-center py-20 opacity-20 italic">Belum ada orderan masuk, Master.</div>
        <?php endif; ?>
    </div>
</body>
</html>