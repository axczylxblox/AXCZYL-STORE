<?php
session_start();
include 'config.php';

// Proteksi Admin - Gunakan session admin lu
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }

if (isset($_POST['tambah'])) {
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $harga = $_POST['harga'];
    $kategori = $_POST['kategori'];

    $query = "INSERT INTO products (name, price, category) VALUES ('$nama', '$harga', '$kategori')";
    if (mysqli_query($conn, $query)) {
        $msg = "Produk Berhasil Ditambah!";
    } else {
        $msg_err = "Gagal: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TAMBAH PRODUK - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #050b18; color: white; font-family: sans-serif; }
        .neon-text { text-shadow: 0 0 8px #00f2ff; color: #00f2ff; }
        .glass { background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.1); }
        .active-scale:active { transform: scale(0.95); transition: 0.1s; }
    </style>
</head>
<body class="p-6">

    <div class="flex items-center gap-4 mb-8">
        <a href="admin_panel.php" class="w-10 h-10 glass rounded-full flex items-center justify-center text-cyan-400 active-scale">
            <i class="fa-solid fa-arrow-left"></i>
        </a>
        <h2 class="text-xl font-bold italic neon-text uppercase tracking-tighter">Tambah Produk</h2>
    </div>

    <?php if(isset($msg)): ?>
        <div class="mb-6 p-4 bg-green-500/10 border border-green-500/50 rounded-2xl text-green-400 text-xs font-bold animate-bounce text-center">
            <i class="fa-solid fa-circle-check mr-2"></i> <?php echo $msg; ?>
        </div>
    <?php endif; ?>

    <form method="POST" class="space-y-5">
        <div class="space-y-2">
            <label class="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Nama Layanan</label>
            <input type="text" name="nama" placeholder="Contoh: 100 Diamond Mobile Legends" 
                class="w-full p-4 bg-slate-900 rounded-2xl border border-slate-800 outline-none focus:border-cyan-500 transition font-bold text-sm" required>
        </div>

        <div class="space-y-2">
            <label class="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Harga (Angka Saja)</label>
            <input type="number" name="harga" placeholder="Contoh: 15000" 
                class="w-full p-4 bg-slate-900 rounded-2xl border border-slate-800 outline-none focus:border-cyan-500 transition font-bold text-green-400 text-sm" required>
        </div>

        <div class="space-y-2">
            <label class="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Kategori (Sesuai Dashboard)</label>
            <select name="kategori" class="w-full p-4 bg-slate-900 rounded-2xl border border-slate-800 outline-none focus:border-cyan-500 transition font-bold text-sm text-cyan-400">
                <optgroup label="E-WALLET" class="bg-slate-950 text-slate-500">
                    <option value="dana">DANA</option>
                    <option value="gopay">GOPAY</option>
                    <option value="seabank">SEABANK</option>
                    <option value="shopeepay">SHOPEEPAY</option>
                    <option value="ovo">OVO</option>
                </optgroup>
                <optgroup label="BANK" class="bg-slate-950 text-slate-500">
                    <option value="bca">BANK BCA</option>
                    <option value="bri">BANK BRI</option>
                </optgroup>
                <optgroup label="LAINNYA" class="bg-slate-950 text-slate-500">
                    <option value="Tools">Tools</option>
                    <option value="pulsa">PULSA</option>
                    <option value="internet">KUOTA / INTERNET</option>
                    <option value="token">TOKEN PLN</option>
                    <option value="smm">SMM PANEL</option>
                </optgroup>
            </select>
        </div>

        <div class="pt-4">
            <button type="submit" name="tambah" class="w-full bg-cyan-600 py-4 rounded-2xl font-black uppercase text-sm shadow-lg shadow-cyan-900/40 active-scale transition">
                Simpan Produk Baru <i class="fa-solid fa-plus ml-1"></i>
            </button>
        </div>
    </form>

    <div class="mt-10 p-5 glass rounded-2xl border border-white/5 opacity-50">
        <p class="text-[10px] leading-relaxed italic text-slate-400">
            <b>INFO:</b> Pastikan kategori yang dipilih sesuai agar produk muncul di halaman depan. Jika memilih <b>DANA</b>, maka produk akan muncul di menu E-Wallet > DANA.
        </p>
    </div>

</body>
</html>