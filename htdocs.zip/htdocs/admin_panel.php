<?php
session_start();
include 'config.php';
// Cek apakah yang login beneran admin
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }

// Ambil total user, total transaksi, dan deposit pending
$total_user = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM users"));
$total_trx = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM transactions"));
$pending_depo = mysqli_num_rows(mysqli_query($conn, "SELECT id FROM deposits WHERE status='pending'"));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #020617; color: white; }
        .glass { background: rgba(15, 23, 42, 0.8); border: 1px solid rgba(255, 255, 255, 0.1); }
        .neon-red { box-shadow: 0 0 15px rgba(239, 68, 68, 0.3); }
    </style>
</head>
<body class="p-6 pb-20">

    <div class="flex justify-between items-center mb-8">
        <div>
            <h1 class="text-2xl font-black italic text-red-500 uppercase tracking-tighter">AXCZYL CONTROL</h1>
            <p class="text-[10px] text-slate-500 font-mono">ROOT ACCESS GRANTED</p>
        </div>
        <a href="logout.php" class="text-slate-500"><i class="fa-solid fa-power-off"></i></a>
    </div>

    <div class="grid grid-cols-2 gap-4 mb-6">
        <div class="p-4 glass rounded-2xl">
            <p class="text-[10px] text-slate-500 uppercase">Total Member</p>
            <p class="text-xl font-bold"><?php echo $total_user; ?></p>
        </div>
        <div class="p-4 glass rounded-2xl">
            <p class="text-[10px] text-slate-500 uppercase">Total Order</p>
            <p class="text-xl font-bold"><?php echo $total_trx; ?></p>
        </div>
    </div>

    <a href="konfirmasi_depo.php" class="block p-5 rounded-2xl bg-red-600/10 border border-red-600 neon-red mb-6 relative overflow-hidden">
        <div class="flex justify-between items-center relative z-10">
            <div>
                <h3 class="font-black text-sm uppercase italic">Konfirmasi Deposit</h3>
                <p class="text-[10px] text-red-400">Ada <span class="font-bold underline"><?php echo $pending_depo; ?></span> permintaan baru.</p>
            </div>
            <i class="fa-solid fa-money-bill-transfer text-2xl text-red-500 animate-pulse"></i>
        </div>
    </a>

    <div class="grid grid-cols-1 gap-4">
        <a href="suntik_saldo.php" class="p-5 glass rounded-2xl flex items-center gap-4 border-l-4 border-green-500">
            <div class="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center">
                <i class="fa-solid fa-syringe text-green-500 text-xl"></i>
            </div>
            <div>
                <p class="font-bold uppercase text-sm italic">Suntik Saldo</p>
                <p class="text-[10px] text-slate-500">Tambah saldo user secara manual.</p>
            </div>
        </a>

        <a href="tambah_produk.php" class="p-5 glass rounded-2xl flex items-center gap-4 border-l-4 border-cyan-500">
    <div class="w-12 h-12 bg-cyan-500/10 rounded-xl flex items-center justify-center">
        <i class="fa-solid fa-plus text-cyan-500 text-xl"></i>
    </div>
    <div>
        <p class="font-bold uppercase text-sm italic">Tambah Produk</p>
        <p class="text-[10px] text-slate-500">Input produk jualan secara manual.</p>
    </div>
        </a>

        <a href="admin_pesanan.php" class="p-5 glass rounded-2xl flex items-center gap-4 border-l-4 border-yellow-500">
    <div class="w-12 h-12 bg-yellow-500/10 rounded-xl flex items-center justify-center">
        <i class="fa-solid fa-shopping-cart text-yellow-500 text-xl"></i>
    </div>
    <div>
        <p class="font-bold uppercase text-sm italic">Kelola Pesanan</p>
        <p class="text-[10px] text-slate-500">ACC atau Batalkan pesanan produk.</p>
    </div>
        </a>
    </div>

</body>
</html>