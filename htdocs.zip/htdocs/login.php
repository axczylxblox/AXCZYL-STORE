<?php
session_start();

// Data yang lu kasih tadi
$admin_user = "axczylscary";
$admin_pass = "aditgntng1_";

if (isset($_POST['login'])) {
    $user = $_POST['user'];
    $pass = $_POST['pass'];

    if ($user === $admin_user && $pass === $admin_pass) {
        $_SESSION['admin'] = $admin_user;
        header("Location: admin_panel.php"); // Lempar ke panel admin
        exit();
    } else {
        $error = "Akses Ditolak! Lu Bukan Axczyl.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { background: #020617; color: white; }
        .neon-glow { box-shadow: 0 0 15px #ff0000; border: 1px solid #ff0000; }
    </style>
</head>
<body class="flex items-center justify-center h-screen px-6">
    <div class="w-full max-w-sm p-8 bg-slate-900 rounded-2xl neon-glow">
        <h2 class="text-2xl font-bold text-center mb-6 text-red-500">AXCZYL ADMIN</h2>
        
        <?php if(isset($error)) echo "<p class='text-red-400 text-xs mb-4 text-center'>$error</p>"; ?>

        <form method="POST">
            <div class="mb-4">
                <input type="text" name="user" placeholder="Username" class="w-full p-3 rounded bg-slate-800 border border-slate-700 focus:outline-none focus:border-red-500" required>
            </div>
            <div class="mb-6">
                <input type="password" name="pass" placeholder="Password" class="w-full p-3 rounded bg-slate-800 border border-slate-700 focus:outline-none focus:border-red-500" required>
            </div>
            <button type="submit" name="login" class="w-full bg-red-600 py-3 rounded-lg font-bold hover:bg-red-700 transition">MASUK SISTEM</button>
        </form>
    </div>
</body>
</html>