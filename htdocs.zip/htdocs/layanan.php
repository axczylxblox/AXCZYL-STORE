<?php
include 'config.php';
$cat = isset($_GET['cat']) ? $_GET['cat'] : 'game';
$products = mysqli_query($conn, "SELECT * FROM products WHERE category='$cat'");
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Layanan - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-[#050b18] text-white p-6">
    <div class="flex items-center gap-4 mb-8">
        <a href="index.php" class="w-10 h-10 bg-slate-900 rounded-full flex items-center justify-center border border-slate-800"><i class="fa-solid fa-arrow-left"></i></a>
        <h2 class="text-xl font-bold uppercase tracking-widest text-cyan-400"><?php echo $cat; ?></h2>
    </div>

    <div class="space-y-4">
        <?php if(mysqli_num_rows($products) > 0): ?>
            <?php while($p = mysqli_fetch_assoc($products)): ?>
            <div class="p-5 bg-slate-900 rounded-2xl border border-slate-800 flex justify-between items-center shadow-lg">
                <div>
                    <h3 class="font-bold text-sm"><?php echo $p['name']; ?></h3>
                    <p class="text-green-400 text-xs font-mono mt-1">Rp <?php echo number_format($p['price']); ?></p>
                </div>
                <a href="order.php?id=<?php echo $p['id']; ?>" class="bg-cyan-600 px-4 py-2 rounded-lg text-[10px] font-bold uppercase active:scale-95 transition">Beli</a>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="text-center mt-20">
                <i class="fa-solid fa-box-open text-4xl text-slate-700 mb-4"></i>
                <p class="text-slate-500 text-sm italic">Produk belum tersedia di kategori ini.</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>