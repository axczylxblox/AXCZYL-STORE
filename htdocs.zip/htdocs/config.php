<?php
$host = "sql101.infinityfree.com";
$user = "if0_41338889";
$pass = "uhFClQZPyEgv4M";
$db   = "if0_41338889_axczyl"; // Pastikan ini nama DB asli lu

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Koneksi Database Gagal: " . mysqli_connect_error());
}
?>