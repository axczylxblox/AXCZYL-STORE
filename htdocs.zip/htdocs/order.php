<?php
session_start();
include 'config.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login_user.php");
    exit();
}

$id_produk = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Ambil data produk
$produk = mysqli_query($conn, "SELECT * FROM products WHERE id='$id_produk'");
$p = mysqli_fetch_assoc($produk);

// Ambil data user (buat cek saldo)
$user_data = mysqli_query($conn, "SELECT * FROM users WHERE id='$user_id'");
$u = mysqli_fetch_assoc($user_data);

if (isset($_POST['order'])) {
    $target = mysqli_real_escape_string($conn, $_POST['target']);
    $harga = $p['price'];

    if ($u['balance'] >= $harga) {
        // 1. Potong Saldo User
        $new_balance = $u['balance'] - $harga;
        mysqli_query($conn, "UPDATE users SET balance='$new_balance' WHERE id='$user_id'");

        // 2. Catat Transaksi
        $service = $p['name'];
        mysqli_query($conn, "INSERT INTO transactions (user_id, service_name, target_number, amount, status) VALUES ('$user_id', '$service', '$target', '$harga', 'success')");

        $success = "Pesanan Berhasil! Saldo lu sisa: Rp " . number_format($new_balance);
    } else {
        $error = "Saldo lu gak cukup, bjir! Topup dulu.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Konfirmasi Order - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#050b18] text-white p-6">
    <h2 class="text-xl font-bold mb-6 text-cyan-400">KONFIRMASI PESANAN</h2>

    <div class="bg-slate-900 p-6 rounded-2xl border border-slate-800 mb-6">
        <p class="text-xs text-slate-500 uppercase tracking-widest">Produk:</p>
        <p class="text-lg font-bold mb-4"><?php echo $p['name']; ?></p>
        
        <p class="text-xs text-slate-500 uppercase tracking-widest">Harga:</p>
        <p class="text-lg font-bold text-green-400">Rp <?php echo number_format($p['price']); ?></p>
    </div>

    <?php if(isset($success)) echo "<div class='bg-green-600/20 text-green-400 p-4 rounded-xl mb-4 text-sm'>$success</div>"; ?>
    <?php if(isset($error)) echo "<div class='bg-red-600/20 text-red-400 p-4 rounded-xl mb-4 text-sm'>$error</div>"; ?>

    <form method="POST" class="space-y-4">
        <div>
            <label class="text-[10px] text-slate-500 uppercase">MASUKAN NOMOR TUJUAN</label>
            <input type="text" name="target" placeholder="Contoh: 08123456789 / 12345678(1234)" class="w-full p-4 bg-slate-800 rounded-xl border border-slate-700 outline-none focus:border-cyan-500" required>
        </div>
        <button type="submit" name="order" class="w-full bg-cyan-600 py-4 rounded-xl font-bold shadow-lg shadow-cyan-900/40">BELI SEKARANG</button>
        <a href="index.php" class="block text-center text-xs text-slate-500 mt-4">Batal & Kembali</a>
    </form>
</body>
</html>