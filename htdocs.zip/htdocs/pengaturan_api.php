<?php
session_start();
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Settings - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-white p-6">
    <a href="admin_panel.php" class="text-cyan-400 text-sm mb-5 block"> Kembali</a>
    <h2 class="text-xl font-bold mb-6 text-red-500">KONFIGURASI API</h2>
    <div class="bg-slate-900 p-6 rounded-2xl border border-red-900/30">
        <p class="text-xs text-slate-400 mb-4 font-mono uppercase italic">Integrasi Digiflazz / SMM Raja</p>
        <div class="space-y-4">
            <div>
                <label class="text-[10px] text-slate-500">API KEY USERNAME</label>
                <input type="text" placeholder="Masukkan Username API" class="w-full p-3 bg-slate-800 rounded border border-slate-700 mt-1">
            </div>
            <div>
                <label class="text-[10px] text-slate-500">PRODUCTION KEY</label>
                <input type="password" placeholder="Key_Produksi_Anda" class="w-full p-3 bg-slate-800 rounded border border-slate-700 mt-1">
            </div>
            <button class="w-full bg-red-600 p-3 rounded font-bold text-sm">UPDATE KONEKSI</button>
        </div>
    </div>
</body>
</html>