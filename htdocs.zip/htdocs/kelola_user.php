<?php
session_start();
include 'config.php';
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }
$users = mysqli_query($conn, "SELECT * FROM users");
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola User - AXCZYL</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-white p-6">
    <a href="admin_panel.php" class="text-cyan-400 text-sm mb-5 block"> Kembali</a>
    <h2 class="text-xl font-bold mb-6">DATABASE USER</h2>
    <div class="overflow-x-auto">
        <table class="w-full text-left bg-slate-900 rounded-xl overflow-hidden">
            <thead class="bg-slate-800 text-xs uppercase text-slate-400">
                <tr>
                    <th class="p-4">Username</th>
                    <th class="p-4">Saldo</th>
                    <th class="p-4">Aksi</th>
                </tr>
            </thead>
            <tbody class="text-sm">
                <?php while($u = mysqli_fetch_assoc($users)): ?>
                <tr class="border-t border-slate-800">
                    <td class="p-4"><?php echo $u['username']; ?></td>
                    <td class="p-4 text-green-400">Rp <?php echo number_format($u['balance']); ?></td>
                    <td class="p-4"><button class="bg-blue-600 px-2 py-1 rounded text-xs">Edit</button></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>