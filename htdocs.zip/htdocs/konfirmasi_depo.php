<?php
session_start();
include 'config.php';
// Cek akses admin
if (!isset($_SESSION['admin'])) { header("Location: login.php"); exit(); }

// Logika ACC atau Reject
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $action = $_GET['action'];
    
    $depo = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM deposits WHERE id='$id'"));
    
    if ($depo && $depo['status'] == 'pending') {
        if ($action == 'acc') {
            $uid = $depo['user_id'];
            $amt = $depo['amount'];
            // Update Saldo User & Status Deposit
            mysqli_query($conn, "UPDATE users SET balance = balance + $amt WHERE id='$uid'");
            mysqli_query($conn, "UPDATE deposits SET status='success' WHERE id='$id'");
            $msg = "Deposit Berhasil Di-ACC!";
        } elseif ($action == 'reject') {
            mysqli_query($conn, "UPDATE deposits SET status='failed' WHERE id='$id'");
            $msg = "Deposit Telah Ditolak!";
        }
        echo "<script>alert('$msg'); window.location='konfirmasi_depo.php';</script>";
    }
}

$list_depo = mysqli_query($conn, "SELECT * FROM deposits WHERE status='pending' ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ACC DEPOSIT - AXCZYL ADMIN</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #020617; color: white; font-family: 'Inter', sans-serif; }
        .neon-border { border: 1px solid rgba(239, 68, 68, 0.3); box-shadow: 0 0 10px rgba(239, 68, 68, 0.1); }
        .glass { background: rgba(15, 23, 42, 0.7); backdrop-filter: blur(10px); }
    </style>
</head>
<body class="p-4 pb-12">

    <div class="flex items-center gap-4 mb-8">
        <a href="admin_panel.php" class="w-10 h-10 flex items-center justify-center rounded-full bg-slate-900 border border-slate-800">
            <i class="fa-solid fa-chevron-left text-red-500"></i>
        </a>
        <div>
            <h1 class="text-xl font-black italic uppercase text-red-500 tracking-tighter">Deposit Review</h1>
            <p class="text-[10px] text-slate-500 font-mono">Validasi pembayaran member</p>
        </div>
    </div>

    <div class="space-y-6">
        <?php if(mysqli_num_rows($list_depo) > 0): ?>
            <?php while($d = mysqli_fetch_assoc($list_depo)): ?>
            <div class="glass rounded-3xl p-5 neon-border relative overflow-hidden">
                <div class="flex justify-between items-start mb-4">
                    <div>
                        <span class="text-[9px] bg-red-600/20 text-red-500 px-2 py-0.5 rounded font-bold uppercase mb-2 inline-block">Pending Request</span>
                        <h3 class="text-lg font-bold text-slate-200">@<?php echo $d['username']; ?></h3>
                        <p class="text-2xl font-black text-green-400">Rp <?php echo number_format($d['amount']); ?></p>
                    </div>
                    <div class="text-right">
                        <p class="text-[10px] text-slate-500 font-mono uppercase">Metode</p>
                        <p class="text-xs font-bold text-cyan-400 italic"><?php echo $d['method']; ?></p>
                    </div>
                </div>

                <div class="mb-5 rounded-2xl overflow-hidden border border-slate-800 bg-black/40">
                    <p class="text-[9px] text-center p-2 text-slate-500 uppercase font-bold tracking-widest border-b border-slate-800">Bukti Transfer</p>
                    <img src="uploads/<?php echo $d['proof_file']; ?>" class="w-full max-h-64 object-contain p-2" alt="Bukti Transfer">
                    <a href="uploads/<?php echo $d['proof_file']; ?>" target="_blank" class="block text-center p-2 text-[10px] text-cyan-500 font-bold hover:bg-cyan-500/10">PERBESAR GAMBAR <i class="fa-solid fa-up-right-from-square ml-1"></i></a>
                </div>

                <div class="flex gap-3">
                    <a href="?action=acc&id=<?php echo $d['id']; ?>" 
                       onclick="return confirm('Yakin saldo udah masuk? Saldo user bakal nambah otomatis!')"
                       class="flex-1 bg-green-600 hover:bg-green-500 py-3 rounded-xl flex items-center justify-center gap-2 font-black text-sm transition shadow-lg shadow-green-900/20">
                        <i class="fa-solid fa-check-double"></i> TERIMA
                    </a>
                    <a href="?action=reject&id=<?php echo $d['id']; ?>" 
                       onclick="return confirm('Tolak deposit ini?')"
                       class="flex-1 bg-slate-800 hover:bg-red-900/30 border border-slate-700 py-3 rounded-xl flex items-center justify-center gap-2 font-black text-sm text-red-500 transition">
                        <i class="fa-solid fa-xmark"></i> TOLAK
                    </a>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="flex flex-col items-center justify-center py-20 opacity-30">
                <i class="fa-solid fa-inbox text-6xl mb-4"></i>
                <p class="italic text-sm">Gak ada deposit yang nunggu, Master.</p>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>