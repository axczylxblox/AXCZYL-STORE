<?php
session_start();
include 'config.php';

if (isset($_POST['order'])) {
    $user_id = $_SESSION['user_id'];
    // Ambil data dari form beli
    $service = mysqli_real_escape_string($conn, $_POST['service_name']);
    $target  = mysqli_real_escape_string($conn, $_POST['target']);
    $harga   = $_POST['price'];

    // 1. Cek Saldo Terkini
    $user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT balance FROM users WHERE id='$user_id'"));
    
    if ($user['balance'] >= $harga) {
        // 2. Potong Saldo
        $potong = mysqli_query($conn, "UPDATE users SET balance = balance - $harga WHERE id='$user_id'");

        if ($potong) {
            // 3. Masukin ke tabel transactions
            $query = "INSERT INTO transactions (user_id, service_name, target_number, amount, status) 
                      VALUES ('$user_id', '$service', '$target', '$harga', 'pending')";
            
            if (mysqli_query($conn, $query)) {
                echo "<script>alert('Order Berhasil Dikirim!'); window.location='riwayat.php';</script>";
            } else {
                // TAMPILIN ERROR KALAU GAGAL INSERT
                die("Gagal Input Database: " . mysqli_error($conn));
            }
        } else {
            die("Gagal Potong Saldo: " . mysqli_error($conn));
        }
    } else {
        echo "<script>alert('Saldo Lu Kurang, Master!'); window.location='index.php';</script>";
    }
}
?>